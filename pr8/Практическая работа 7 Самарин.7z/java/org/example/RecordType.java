package org.example;

import org.springframework.stereotype.Service;

@Service
public enum RecordType {
  RESUME,
  VACANCY
}