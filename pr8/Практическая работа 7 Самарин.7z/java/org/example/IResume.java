package org.example;

public interface IResume {


  public void setResumeSpecificData(Object resumeSpecificData);
}
