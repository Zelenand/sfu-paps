package org.example;

public class UserImpl extends User{
}
