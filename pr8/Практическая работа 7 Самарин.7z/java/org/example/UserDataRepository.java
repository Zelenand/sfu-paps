package org.example;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDataRepository {
  public void insertUser(){
    //работа с SQL
  }

  public User getUser(int id){
    //работа с SQL
    return null;
  }

  public List<User> getAllUsers(){
    //работа с SQL
    return null;
  }
}
