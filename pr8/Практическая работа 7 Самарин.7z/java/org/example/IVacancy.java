package org.example;

public interface IVacancy{


  public void setVacancySpecificData(Object vacancySpecificData);
}
