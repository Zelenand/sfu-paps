package org.example;

public abstract class UserFactory {
  public abstract User createUser (Object userData);
}
