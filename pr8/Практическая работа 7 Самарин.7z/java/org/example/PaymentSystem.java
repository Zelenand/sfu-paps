package org.example;

public class PaymentSystem {

  public static void makePayment(){
    //работа с внешней системой оплаты
  }
}
